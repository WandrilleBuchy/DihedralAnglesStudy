""" Module for performing principal geodesic analysis """

import random as random
from .inputs import *
import math as mt


def chi(x, v, point):
    a = mt.sqrt(np.power((np.inner(x, point)), 2) + np.power((np.inner(v, point)), 2))
    if a > 1:
        return 1.
    return a


def epsilon(chis):
    if chis >= 1.:
        return 1.
    if chis > 1.:
        print("warning")
    return mt.acos(chis) / (chis * mt.sqrt(1 - np.power(chis, 2)))


def lambda1(x, v, pointset):
    suma = 0
    for point in pointset:
        c = epsilon(chi(x, v, point))
        suma = suma + c * np.power(np.dot(x, point), 2)
    return suma


def lambda2(x, v, pointset):
    suma = 0
    for point in pointset:
        c = epsilon(chi(x, v, point))
        suma = suma + c * np.dot(x, point) * np.dot(v, point)
    return suma


def lambda3(x, v, pointset):
    suma = 0
    for point in pointset:
        c = epsilon(chi(x, v, point))
        suma = suma + c * np.power(np.dot(v, point), 2)
    return suma


def psi1(l1, l2, l3, x, v, pointset):
    n = len(x)
    suma = np.zeros(n)
    for point in pointset:
        point = np.asarray(point, dtype=float)
        c = epsilon(chi(x, v, point))
        suma += point * c * (l3 * np.inner(x, point) - l2 * np.inner(v, point)) / (
            l1 * l3 - np.power(l2, 2))
    return suma


def psi2(l1, l2, l3, x, v, pointset):
    n = len(x)
    suma = np.zeros(n)
    for point in pointset:
        point = np.asarray(point, dtype=float)
        c = epsilon(chi(x, v, point))
        suma += point * c * (l2 * np.dot(x, point) - l1 * np.dot(v, point)) / (
            -l1 * l3 + np.power(l2, 2))
    return suma


def fu(x, v, dataset):
    suma = 0
    for point in dataset:
        suma = suma + mt.acos(
            mt.sqrt(np.inner(x, point) * np.inner(x, point) + np.inner(v, point) * np.inner(v, point)))
    return suma


def ab(t, i, x, v):
    return np.inner(x, i) * mt.cos(t) + np.inner(v, i) * mt.sin(t)


def bb(t, i, x, v):
    return np.inner(v, i) * mt.cos(t) - np.inner(x, i) * mt.sin(t)


def chi2(t, w, i, x, v):
    a = mt.sqrt(np.power(ab(t, i, x, v), 2) + np.power((np.inner(w, i)), 2))
    if a > 1:
        return 1
    return a


def phi(w, t, dataset, x, v):
    n = len(w)
    suma = np.zeros(n)
    s = 0.0
    for point in dataset:
        point = np.asarray(point, dtype=float)
        c = epsilon(chi2(t, w, point, x, v))
        suma += c * np.inner(w, point) * point
        s += c * np.power(np.inner(w, point), 2)
    return suma / s


def projection_1(dataset, x, v):
    proj = []
    for point in dataset:
        proj.append((np.inner(x, point) * x + np.inner(v, point) * v) / mt.sqrt(
            np.power(np.inner(x, point), 2) + np.power(np.inner(v, point), 2)))
    return proj


def variance(dataset, y, w):
    suma = 0
    for point in dataset:
        suma += (np.inner(y, point) * np.inner(y, point) + np.inner(w, point) * np.inner(w, point)) / len(dataset)
    return float(suma)


def get_angles(dataset, v, x, t, origin):
    angles = []
    norm_origin = np.inner(origin, origin)
    for point in dataset:
        cos_val = np.clip(np.inner(point, x) / norm_origin, -1.0, 1.0)
        if mt.asin(np.clip(np.inner(point, v) / norm_origin, -1.0, 1.0)) > 0:
            angles.append(mt.acos(cos_val) - t)
        else:
            angles.append(-mt.acos(cos_val) - t)
    return np.array(angles)


def dist(x, v):
    return [mt.sqrt(np.inner(x, x)), mt.sqrt(np.inner(v, v))]


def dist1(w, t):
    return [mt.sqrt(np.inner(w, w)), abs(t)]


def indi(name):
    z = np.zeros(len(name[0]))
    num = np.copy(z)
    while np.array_equal(num, z):
        nume = random.randint(0, (len(name)) - 1)
        num = name[nume]
    return num


def indu(name, indigo):
    for i in range(len(indigo)):
        if (indigo[i]) != 0:
            return i
    return 0


def initializeFirst(name, indigo, ind):
    c = sum(indigo)
    v1 = [1.0 for i in indigo]
    c = (indigo[ind] - c) / indigo[ind]
    v1[ind] = c
    norm = mt.sqrt(np.inner(v1, v1))
    v1 = np.array(v1) / norm
    return np.asarray(indigo, dtype=float), v1


def runFirst(d1, d2, name, x, v, first_stop):
    x = np.asarray(x, dtype=float)
    v = np.asarray(v, dtype=float)
    while d1 > first_stop and d2 > first_stop:
        x1 = x.copy()
        v1 = v.copy()
        l1 = lambda1(x, v, name)
        l2 = lambda2(x, v, name)
        l3 = lambda3(x, v, name)
        c0 = psi1(l1, l2, l3, x, v, name)
        c0 = c0 / mt.sqrt(float(np.inner(c0, c0)))
        psi2_val = psi2(l1, l2, l3, x, v, name)
        v = psi2_val - np.inner(psi2_val, c0) * c0
        v = v / mt.sqrt(float(np.inner(v, v)))
        x = c0
        d1 = dist(x1 - x, v1 - v)[0]
        d2 = dist(x1 - x, v1 - v)[1]
    return x, v


def initializeSecond(name, x, v, ind):
    t = 0.0
    diff = np.asarray(name[ind + 1], dtype=float) - np.asarray(name[ind], dtype=float)
    w = diff - np.inner(diff, x) * x - np.inner(diff, v) * v
    w = w / mt.sqrt(float(np.inner(w, w)))
    return t, w


def runSecond(d1, d2, name, x, v, t, w, second_stop):
    w = np.asarray(w, dtype=float)
    y = x.copy()
    while (d1 > second_stop) and (d2 > second_stop):
        t1 = t
        w1 = w.copy()
        z0 = phi(w, t, name, x, v)
        w = z0 - np.inner(z0, x) * x - np.inner(z0, v) * v
        norm_w = float(np.inner(w, w))
        w = w / norm_w
        suma = 0.0
        s = 0.0
        for i in name:
            i = np.asarray(i, dtype=float)
            suma += epsilon(chi2(t, w, i, x, v)) * np.inner(x, i) * np.inner(v, i)
            s += epsilon(chi2(t, w, i, x, v)) * (np.power(np.inner(x, i), 2) + np.power(np.inner(v, i), 2))
        t = 0.5 * mt.atan(2 * suma / s)
        d1 = dist1(w1 - w, t1 - t)[0]
        d2 = dist1(w1 - w, t1 - t)[1]
        y = x * mt.cos(t) + v * mt.sin(t)
    return y, w


class geopca:
    def __init__(self, a, first_stop=0.00001, second_stop=0.0005):
        name = [np.asarray(p, dtype=float) for p in a]
        indg = indi(name)
        indr = indu(name, indg)
        self.x, self.v = initializeFirst(name, indg, indr)
        self.x, self.v = runFirst(1., 1., name, self.x, self.v, first_stop)
        self.t, self.w = initializeSecond(name, self.x, self.v, indr)
        self.y, self.w = runSecond(1., 1., name, self.x, self.v, self.t, self.w, second_stop)
        proj_1 = projection_1(name, self.x, self.v)
        proj_2 = projection_1(name, self.y, self.w)
        self.origin = self.y
        self.angles1 = get_angles(proj_1, self.v, self.x, self.t, self.origin) * 180 / np.pi
        self.angles2 = get_angles(proj_2, self.w, self.y, 0.0, self.origin) * 180 / np.pi
        self.dataset = np.vstack((self.angles1, self.angles2)).T
        self.variance1 = variance(name, self.x, self.v)
        self.variance2 = variance(name, self.y, self.w)

    def __repr__(self):
        return str(self.variance1)+", "+str(self.variance2)

    def project(self, a):
        name1 = [np.asarray(p, dtype=float) for p in a]
        proj_11 = projection_1(name1, self.x, self.v)
        proj_21 = projection_1(name1, self.y, self.w)
        angles1 = get_angles(proj_11, self.v, self.x, self.t, self.origin) * 180 / np.pi
        angles2 = get_angles(proj_21, self.w, self.y, 0.0, self.origin) * 180 / np.pi
        c = Angles()
        c.dataset = np.vstack((angles1, angles2)).T
        c.variance1 = variance(name1, self.x, self.v)
        c.variance2 = variance(name1, self.y, self.w)
        return c

    def write(self, name):
        with open(name, "w") as fil:
            for i in range(self.dataset.shape[0]):
                fil.write(str(self.angles1[i]) + "," + str(self.angles2[i]) + "\n")
