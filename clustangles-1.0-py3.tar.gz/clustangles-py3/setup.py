from setuptools import setup

setup(name='clustangles',
      version='1.0',
      description='Analysis and clustering of angular data',
      url='http://clustangles.limlab.ibms.sinica.edu.tw',
      author='Karen Sargsyan',
      author_email='karsar@ibms.sinica.edu.tw',
      license='MIT',
      packages=['clustangles'],
      zip_safe=False)